import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.findmycollege.R;

public class form extends AppCompatActivity {
    dbHelper myDb;
    EditText uname, uemail, ucontact, urank, upercentage, uquery;
    Button btnAddData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form);
        myDb = new dbHelper(this);

        uname = (EditText) findViewById(R.id.id_fname);
        uemail = (EditText) findViewById(R.id.id_email);
        ucontact = (EditText) findViewById(R.id.id_contact);
        urank = (EditText) findViewById(R.id.id_rankexam);
        upercentage = (EditText) findViewById(R.id.id_boardper);
        uquery = (EditText) findViewById(R.id.id_qry);
        btnAddData = (Button) findViewById(R.id.id_formsubmit);

        AddData();
    }

    private void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(uname.getText().toString(), uemail.getText().toString(), ucontact.getText().toString(), urank.getText().toString(), upercentage.getText().toString(), uquery.getText().toString());
                        if (isInserted == true)
                            Toast.makeText(form.this, "Data inserted successfully ", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(form.this, "Failed", Toast.LENGTH_LONG).show();

                        uname.setText("");
                        uemail.setText("");
                        ucontact.setText("");
                        urank.setText("");
                        upercentage.setText("");
                        uquery.setText("");


                    }
                }
        );
    }
}