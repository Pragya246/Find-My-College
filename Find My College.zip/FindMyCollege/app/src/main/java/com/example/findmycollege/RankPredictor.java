package com.example.findmycollege;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RankPredictor extends AppCompatActivity  {
    Button submit;
    EditText mark1;
    TextView tx;
Button v;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_rank_predictor );
        mark1 = (EditText) findViewById( R.id.mark );
        v = (Button) findViewById(R.id.vc);
       v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  int i = Integer.parseInt(mark1.getText().toString());
                openNewActivity(i);
            }
        });
try{
        tx = (TextView) findViewById( R.id.rnk );


    submit = (Button) findViewById( R.id.open );submit.setOnClickListener( new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          int i = Integer.parseInt(mark1.getText().toString());
            System.out.println( i);
            if (i == 300) {
                tx.setText( "1" );
            } else if (i < 300 && i >= 285) {
                tx.setText( "2 to 100" );

            } else if (i < 285 && i >= 275) {
                tx.setText( "100 to 200" );

            } else if (i < 275 && i >= 260) {
                tx.setText( "200 to 500" );

            } else if (i < 260 && i >= 250) {
                tx.setText( "500 - 1000" );

            } else if (i < 250 && i >= 240) {
                tx.setText( "1000-1500" );

            } else if (i < 240 && i >= 220) {
                tx.setText( "1500-3500" );

            } else if (i < 220 && i >= 200) {
                tx.setText( "3500 to 6000" );

            } else if (i < 200 && i >= 180) {
                tx.setText( "6000 to 9500" );
            } else if (i < 180 && i >= 150) {
                tx.setText( "9500 to 15000" );
            } else if (i < 150 && i >= 120) {
                tx.setText( "15000 to 35000" );

            } else if (i < 120 && i >= 90) {
                tx.setText( "35000 to 60000" );

            } else if (i < 90 && i >= 60) {
                tx.setText( "60000 to 120000" );

            } else if (i > 60 && i >= 35) {
                tx.setText( "150000 to 250000" );

            } else if (i > 35 && i <= 20) {
                tx.setText( "250000 to 550000" );
            }else if (i > 300) {
                tx.setText( "invalid marks" );


            }else if(i<20)
            {tx.setText( "more than 6lakhs" );}
        }

    } );} catch (NumberFormatException e) {
    e.printStackTrace();
}
    }

    private void openNewActivity(int i) {
        Intent intent = new Intent(this, collegeengg.class);
intent.putExtra( "marks",i );
        startActivity(intent);
    }
}


