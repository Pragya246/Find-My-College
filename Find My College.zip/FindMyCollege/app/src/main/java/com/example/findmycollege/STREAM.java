package com.example.findmycollege;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class STREAM extends AppCompatActivity {
Button button;
Button button2;
Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stream);

        button = (Button) findViewById(R.id.engg);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                engg();
            }
        });
        button2=(Button)findViewById( R.id.button3 );
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                med();
            }
        });

        button3=(Button)findViewById( R.id.cla );
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                law();
            }
        });
    }

 public void law() {Intent intent = new Intent(this, rnkpredclat.class);
     startActivity(intent);
    }

    public void engg(){
        Intent intent = new Intent(this, RankPredictor.class);
        startActivity(intent);
    }
public void med(){
        Intent intent =new Intent(this,medrank.class);
        startActivity( intent );
}
    }
