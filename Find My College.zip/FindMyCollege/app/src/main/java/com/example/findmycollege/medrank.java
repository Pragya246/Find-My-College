package com.example.findmycollege;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class medrank extends AppCompatActivity {
    Button b1;
    TextView tx;
    EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_medrank );
    tx=(TextView)findViewById( R.id.rnk2) ;
    e1 =(EditText)findViewById( R.id.mrk2 );
    //b1=(Button)findViewById( R.id.sbmt2 );
      //  b1.setOnClickListener(new View.OnClickListener() {
        //    @Override
          //  public void onClick(View v) {  int i = Integer.parseInt(e1.getText().toString());
            //    openNewActivity(i);
            //}
        //});
        try{
            tx = (TextView) findViewById( R.id.rnk2 );


            b1 = (Button) findViewById( R.id.sbmt2 );b1.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int m1 = Integer.parseInt(e1.getText().toString());
                    System.out.println( m1);
                    if(m1>=701&&m1<=720)
                    tx.setText("1-75");
                    else if(m1>=691&&m1<700)
                        tx.setText("76-250");
                    else if(m1>=681&&m1<=690)
                        tx.setText("250-587");
                    else if(m1>=671&&m1<=698)
                        tx.setText("581-1180");
                    else if(m1>=661&&m1<=670)
                        tx.setText("1181-2200");
                    else if(m1>=651&&m1<=660)
                        tx.setText("3751-5750");
                    else if(m1>=631&&m1<=640)
                        tx.setText("5751-8350");
                    else if(m1>=621&&m1<=630)
                        tx.setText("8351-11350");
                    else if(m1>=611&&m1<=620)
                        tx.setText("11351-15200");

                    else if(m1>=601&&m1<=610)
                        tx.setText("15201-19600");
                    else if(m1>=591&&m1<=600)
                        tx.setText("19601-24570");
                    else if(m1>=581&&m1<=590)
                        tx.setText("24571-29965");
                    else if(m1>=571&&m1<=580)
                        tx.setText("29966-35650");
                    else if(m1>=561&&m1<=570)
                        tx.setText("35651-40000");
                    else if(m1>=551&&m1<=560)
                        tx.setText("40000-46000");
                    else if(m1>=541&&m1<=550)
                        tx.setText("46000-50000");
                    else if(m1>=531&&m1<=540)
                        tx.setText("50000-56000");
                    else if(m1>=521&&m1<=530)
                        tx.setText("56000-60000");
                    else if(m1>=491&&m1<=520)
                        tx.setText("56000-90000");
                }

            } );} catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    private void openNewActivity(int i) {
        Intent intent = new Intent(this, collegeengg.class);
        intent.putExtra( "marks",i );
        startActivity(intent);
    }
    }
