package com.example.findmycollege;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link VIEW_COLLEGE#newInstance} factory method to
 * create an instance of this fragment.
 */
public class VIEW_COLLEGE extends Fragment {
    String[] collegest2 = {
            "IIIT RAIPUR", "IIT BBSR",
            "NIT RAIPUR", "PEC",
            "NSUT ","BIT MESRA","NIT NAGALAND","DU ","NIT MIZORAM","NIT MEGHALAYA","JADHAVPUR UNIV","ITER","IICT","AIIMS DELHI","JNU RAIPUR","GMC BILASPUR"
    };
    ListView list;
    String[] subtitle = {
            "Raipur", "Bhubanesbar",
            "Raipur", "Chandigarh",
            "Delhi","Mesra","Nagaland","Delhi","Mizoram","Meghalaya","jadhavpur","Orrisa","Gandhinagar","DELHI","RAIPUR","GMC BILASPUR",
    };
    private View mView;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public VIEW_COLLEGE() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment VIEW_COLLEGE.
     */
    // TODO: Rename and change types and number of parameters
    public static VIEW_COLLEGE newInstance(String param1, String param2) {
        VIEW_COLLEGE fragment = new VIEW_COLLEGE();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       mView=inflater.inflate(R.layout.fragment_viewcollege, container, false);

       return mView;


    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        MyListAdapter adapter= new MyListAdapter(getActivity(),collegest2, subtitle);
        list = (ListView) mView.findViewById( R.id.list );
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    String url = "https://www.iiitnr.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);

                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    String url = "https://www.iiit-bh.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }

                else if(position == 2) {
                    String url = "http://www.nitrr.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);

                }
                else if(position == 3) {

                    String url = "https://www.pec.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }
                else if(position == 4) {

                    String url = "https://www.nsit.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }
                else if(position ==5)
                { String url = "https://www.bitmesra.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);

                } else if(position == 6) {

                    String url = "https://nitnagaland.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                } else if(position == 7) {

                    String url = "http://du.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                } else if(position == 8) {

                    String url = "https://www.nitmz.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }
            }
        });
    }
}