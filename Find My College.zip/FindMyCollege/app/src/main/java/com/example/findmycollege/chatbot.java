package com.example.findmycollege;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class chatbot extends AppCompatActivity {
EditText e1;
Button q1;
TextView t1;
TextView t2;
    @Override
  public void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_chatbot );
        e1=(EditText) findViewById( R.id.bot_msg );
        String s1=e1.getText().toString();
        q1= (Button) findViewById(R.id.button_send);
        t1=(TextView)findViewById( R.id.display ) ;
        t2=(TextView)findViewById( R.id.own_msg );
        t1.setVisibility( View.INVISIBLE );
        t2.setVisibility( View.INVISIBLE );
        q1.setOnClickListener(new View.OnClickListener() {String s2=e1.getText().toString();
            @Override
            public void onClick(View v) {  chatreply();
            }

        });

    }           public void chatreply() {t1.setVisibility( View.VISIBLE );
    t2.setVisibility( View.VISIBLE );
        t2.setText( e1.getText() );

        System.out.println( e1.getText().toString() );
        String regex="Engineering";
        Pattern pattern1 = Pattern.compile(regex,Pattern.CASE_INSENSITIVE);

        Matcher m = pattern1.matcher(e1.getText().toString());
        String r2="(Dates)|(DATE)";
        Pattern pattern2=Pattern.compile( r2,Pattern.CASE_INSENSITIVE );
        Matcher m1=pattern2.matcher( e1.getText().toString());
String r3 ="IIT";
Pattern p3 =Pattern.compile( r3,Pattern.CASE_INSENSITIVE );
Matcher m3=p3.matcher( e1.getText().toString() );
String r4 ="(JEE CUTTOFF)|(cutoff)";

Pattern p4=Pattern.compile(  r4,Pattern.CASE_INSENSITIVE);
Matcher m4= p4.matcher( e1.getText().toString() );
String r5="(HII)|(HELLO)";
Pattern p5= Pattern.compile( r5,Pattern.CASE_INSENSITIVE );
Matcher m5 =p5.matcher( e1.getText().toString() );

String r6="(NIT)|(NIT)";
Pattern p6=Pattern.compile( r6,Pattern.CASE_INSENSITIVE );
Matcher m6 =p6.matcher( e1.getText().toString() );
 String r7 ="(MEDICAL)|(NEET)";
 Pattern p7= Pattern.compile( r7,Pattern.CASE_INSENSITIVE );
 Matcher m7=p7.matcher( e1.getText().toString() );
 String r8="(NEET CUTOFF)|(MEDICAL CUTOFF)";
 Pattern p8 =Pattern.compile( r8,Pattern.CASE_INSENSITIVE );
 Matcher m8=p8.matcher( e1.getText().toString() );
 String r9 ="(DENTAL)";
 Pattern p9=Pattern.compile( r9,Pattern.CASE_INSENSITIVE );
 Matcher m9 =p9.matcher( e1.getText().toString() );
 String r10="(LAW)|(COLLEGE)";
 Pattern p10 =Pattern.compile("r10",Pattern.CASE_INSENSITIVE  );
 Matcher m10 = p10.matcher( e1.getText().toString() );
String r11="(JEE MARKS 100 to 200)";
Pattern p11=Pattern.compile( "r11",Pattern.CASE_INSENSITIVE );
Matcher m11=p11.matcher( e1.getText().toString() );
        String r12="(JEE MARKS less than 100)";
        Pattern p12=Pattern.compile( "r12",Pattern.CASE_INSENSITIVE );
        Matcher m12=p12.matcher( e1.getText().toString() );
        String r13  ="love you";
        Pattern p13 = Pattern.compile( r13,Pattern.CASE_INSENSITIVE );
        Matcher m13 =p13.matcher( e1.getText().toString() );

if(m.find())
{t1.setText( "THE TOP COLLEGES For Technical are 1.BIT MESRA \n 2.IIT BOMBAY \n 3.IIT KHARAGPUR \n  4.IIT RORKEE \n5.IIT Delhi "
    );}
else if(m1.find())
{t1.setText( "IMPORTANT DATES \n jee 21 Feb \n NEET 5th MAY" );

}
else if(m3.find())
{t1.setText("TOP IITS ARE \n 1.IIT MADRAS \n 2.IIT BOMBAY \n 3.IIT KHARAGPUR \n 4.IIT KANPUR");


}
else if(m4.find())
{t1.setText(  "JEE CUT-OFF \n GENERAL CUT-OFF 90 percentile \nEWS CUT-OFF 70 percentile\n OBC CUT-OFF 73 \n SC|ST CUT-OFF 43-56 ");

}
else if(m5.find()){
    t1.setText( "HELLO THIS IS SHWETA \n HOW MAY I HELP " );
}
else if(m6.find())
{    t1.setText( "TOP NIT ARE \n 1.NIT TRICHY\n2.NIT ROUKELA\n3.NIT SURATKAL\n 4.NIT WARANGAL \n 5.NIT CALICUT" );

}
else if(m7.find())
{
    t1.setText( "TOP MEDICAL COLLEGES ARE:\n1.AIIMS DELHI \n 2.PGIMER CHANDIGARH \n 3.CMC VELLORE \n 4.KMC MANIPAL \n5.KGMU LUCKNOW" );
}
else if (m8.find())
{t1.setText( "NEET CUT OFF\n 1.GENERAL|OBC 112 marks \n2.SC|ST 109 marks" );

}
else if(m9.find())
{
    t1.setText( "TOP DENTAL COLLEGE\n1.Bilaspur Dental College \n2.rk Dental \n3.GDC RAIPUR" );
}
else if(m10.find())
{
    t1.setText( "TOP LAW COLLEGES \n 1. NLSIU BANGLORE\n 2. NLU NEW DELHI \n 3.NLASAR HYDERABAD \n4. IIT KGP (LAW)" );
}else if(m11.find())
{
    t1.setText( "YOU WILL QUALIFY FOR ADVANCE \n YOUR LIKELY TO GET MID RANGE NIT'S" );
} else if(m12.find()){
    t1.setText( "CHANCES ARE LOW FOR QULIFICATION YOU AY APPLY IN TIER 3 COLLEGES" );
} else if(m13.find()){
    t1.setText( "Sorry I have a bf" );
}
else{
    t1.setText( "SORRY I COULD NOT GET YOU " );
}
e1.setText( "" );

}


    }

