package com.example.findmycollege;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class rnkpredclat extends AppCompatActivity {
Button b1;
    EditText mark1;
    TextView tx;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_rnkpredclat );
        mark1 = (EditText) findViewById( R.id.mk4 );
        //b1=(Button)findViewById( R.id .click);
        try{
            tx = (TextView) findViewById( R.id.rnk5 );


            b1 = (Button) findViewById( R.id.click );b1.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int m = Integer.parseInt(mark1.getText().toString());
                    if(m>=125&&m<=130)
                        tx.setText("1");
                    else if(m>=120&&m<=124)
                        tx.setText("2-3");
                    else if(m>=115&&m<=119)
                        tx.setText("4-5");
                    else if(m>=110&&m<=114)
                        tx.setText("6");
                    else if(m>=105&&m<=109)
                        tx.setText("7-9");
                    else if(m>=100&&m<=104)
                        tx.setText("10-19");
                    else if(m>=95&&m<=99)
                        tx.setText("20-57");
                    else if(m>=90&&m<=94)
                        tx.setText("58-173");
                    else if(m>=85&&m<=89)
                        tx.setText("174-362");
                    else if(m>=75&&m<=84)
                        tx.setText("363-743");
                    else if(m>=70&&m<=74)
                        tx.setText("1412-2318");
                    else if(m>=65&&m<=69)
                        tx.setText("2319-3572");
                    else if(m>=60&&m<=64)
                        tx.setText("3573-5200");
                    else if(m>=55&&m<=59)
                        tx.setText("5210-7284");
                    else if(m>=50&&m<=54)
                        tx.setText("7285-9841");
                    else if(m>=45&&m<=49)
                        tx.setText("9842-12994");
                    else if(m>=40&&m<=44)
                        tx.setText("1299-16746");
                    else if(m>=35&&m<=39)
                        tx.setText("16747-21135");
                    else if(m>=30&&m<=34)
                        tx.setText("21136-26442");
                    else if(m>=25&&m<=30)
                        tx.setText("26443-32188");
                    else if(m>=20&&m<=24)
                        tx.setText("32189-38320");
                    else if(m>=15&&m<=19)
                        tx.setText("38321-44066");
                    else if(m>=10&&m<=14)
                        tx.setText("44067-48884");
                    else if(m>=5&&m<=9)
                        tx.setText("48885-51683");
                    else if(m>=0&&m<=4)
                        tx.setText("51684-52956");
                }

            } );} catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
    }
