package com.example.findmycollege.ui;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbHelper extends SQLiteOpenHelper {
    public static final String dbname = "form.db";
    public static final String TABLE_NAME = "Form_table";
    public static final String col1 = "ID";
    public static final String col2 ="Name";
    public static final String col3 = "Email";
    public static final String col4 = "Contact";
    public static final String col5 = "Rank";
    public static final String col6 = "Percentage";
    public static final String col7 = "Query";
    //private SQLiteDatabase db;

    public dbHelper(@Nullable Context context) {
        super(context, dbname, null, 1);
        //super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +" (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, EMAIL TEXT, CONTACT TEXT, RANK TEXT, PERCENTAGE TEXT, QUERY TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
    public boolean insertData (String sname, String semail, String scontact, String srank, String spercentage, String squery){
        SQLiteDatabase db = this.getWritableDatabase();


        ContentValues cv = new ContentValues();
        cv.put(col2,sname);
        cv.put(col3, semail);
        cv.put(col4,scontact);
        cv.put(col5,srank);
        cv.put(col6, spercentage);
        cv.put(col7,squery);
        long result = db.insert(TABLE_NAME, null, cv);
        if (result==-1)
            return false;
        else
            return true;
    }
}
