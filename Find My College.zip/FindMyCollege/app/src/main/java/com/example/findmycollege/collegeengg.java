package com.example.findmycollege;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ListView;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class collegeengg extends AppCompatActivity {
    ListView list;

    String[] collegest2 = {
            "IIIT RAIPUR", "IIT BBSR",
            "NIT RAIPUR", "PEC",
            "NSUT ","BIT MESRA","NIT NAGALAND","DU ","NIT MIZORAM","NIT MEGHALAYA","JADHAVPUR UNIV","ITER","IICT"
    };

    String[] subtitle = {
            "Raipur", "Bhubanesbar",
            "Raipur", "Chandigarh",
            "Delhi","Mesra","Nagaland","Delhi","Mizoram","Meghalaya","jadhavpur","Orrisa","Gandhinagar"
    };
String[] collegest1={
        "NIT ROUKELA","BHU","Anna Univ","IIST","IIIT","NIT SILCHAR","NIT TRICHY","NIT BHOPAL","IIIT NAGPUR","TRIDENT","ISM"
};
String [] sub2={"Rourkela","Banaras","Telengana","Shibpur","Banglore","Silchar","Trichy","Bhopal","Napur","Orissa","Dhanbad"};
String [] collegest3={
        "Rungta","CET","SRM","MU","RIT","SRM","NIT MANIPUR","New Town College","Rohtak Engg College"
};
String [] sub3={
        "Bhilai","BBSR","CHENNAI","Mumbai","NAGPUR","MANIPUR","KOLKATA","ROHTAK"
};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_collegeengg );

        Intent iin= getIntent();
        Bundle b = iin.getExtras();
        int m=b.getInt( "marks" );
        System.out.println( m );
        if(m>100&&m<200)
        {MyListAdapter adapter=new MyListAdapter(this, collegest2, subtitle);
        list=(ListView)findViewById(R.id.list);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    String url = "https://www.iiitnr.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);

                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    String url = "https://www.iiit-bh.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }

                else if(position == 2) {
                    String url = "http://www.nitrr.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);

                }
                else if(position == 3) {

                    String url = "https://www.pec.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }
                else if(position == 4) {

                    String url = "https://www.nsit.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }
                else if(position ==5)
                { String url = "https://www.bitmesra.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);

                } else if(position == 6) {

                    String url = "https://nitnagaland.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                } else if(position == 7) {

                    String url = "http://du.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);   
                } else if(position == 8) {

                    String url = "https://www.nitmz.ac.in/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData( Uri.parse(url));
                    startActivity(i);
                }
            }
        });
    }else if(m>=200&&m<=300)
        {
            MyListAdapter adapter=new MyListAdapter(this, collegest1, sub2);
            list=(ListView)findViewById(R.id.list);
            list.setAdapter(adapter);
        }else if(m<=100)
        {
            MyListAdapter adapter=new MyListAdapter(this, collegest3, sub3);
            list=(ListView)findViewById(R.id.list);
            list.setAdapter(adapter);
        }
}}